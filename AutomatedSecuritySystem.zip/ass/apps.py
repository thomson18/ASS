from django.apps import AppConfig


class AssConfig(AppConfig):
    name = 'ass'
